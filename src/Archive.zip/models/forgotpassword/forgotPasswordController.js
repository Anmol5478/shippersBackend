exports.forgotPassword = async (req,res)=>{

    try{

        await forgotPasswordService.forgotPassword(
            req.body.email
        );

        res.json({

            responseCode:"00",
            success:true,
            message:"OTP Sent"

        });

    }

    catch(err){

        res.status(400).json({

            responseCode:"01",
            success:false,
            message:err.message

        });

    }

};