const authRepository = require("../auth/authRepository");
const forgotPasswordRepository = require("./forgotPasswordRepository");
const forgotPasswordRepository = require("./forgotPasswordRepository");
const bcrypt = require("bcrypt");

const forgotPassword = async (email) => {

    const user = await authRepository.findUserByEmail(email);

    if (!user) {
        throw new Error("Email not found");
    }

    const otp = Math.floor(
        100000 + Math.random() * 900000
    ).toString();

    const expiry = new Date(
        Date.now() + 10 * 60 * 1000
    );

    await forgotPasswordRepository.saveOTP(
        email,
        otp,
        expiry
    );

    await forgotPasswordRepository.sendOTP(
        email,
        otp
    );

};
const verifyOTP = async (
    email,
    otp
) => {

    const record =
        await forgotPasswordRepository.getOTP(email);

    if (!record) {

        throw new Error("OTP not found");

    }

    if (record.is_used) {

        throw new Error("OTP already used");

    }

    if (record.otp !== otp) {

        throw new Error("Invalid OTP");

    }

    if (new Date() > record.expires_at) {

        throw new Error("OTP expired");

    }

};
const resetPassword = async (
    email,
    otp,
    password
) => {

    await verifyOTP(email, otp);

    const hashed =
        await bcrypt.hash(password,10);

    await authRepository.updatePassword(
        email,
        hashed
    );

    await forgotPasswordRepository.deleteOTP(email);

};
