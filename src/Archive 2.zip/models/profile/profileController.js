const profileService = require("./profileService");

/**
 * Get complete user profile with dashboard statistics
 */
const getProfile = async (req, res) => {
  try {
    const { user_id } = req.params;

    const data = await profileService.getProfile(user_id);

    return res.status(200).json({
      success: true,
      message: "Profile fetched successfully",
      data,
    });
  } catch (error) {
    console.error("Get profile error:", error);

    return res.status(404).json({
      success: false,
      message: error.message || "Failed to fetch profile",
    });
  }
};

module.exports = {
  getProfile,
};