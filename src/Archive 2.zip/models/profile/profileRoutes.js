const express = require("express");

const router = express.Router();

const profileController =
  require("./profileController");


/**
 * @swagger
 * /api/profile/{user_id}:
 *   get:
 *     summary: Get user profile
 *     tags:
 *       - Profile
 *     parameters:
 *       - in: path
 *         name: user_id
 *         required: true
 *         schema:
 *           type: string
 *         example: U0001
 *     responses:
 *       200:
 *         description: Profile fetched successfully
 */
router.get(
  "/:user_id",
  profileController.getProfile
);


/**
 * @swagger
 * /api/profile/{user_id}/stats:
 *   get:
 *     summary: Get user profile statistics
 *     tags:
 *       - Profile
 *     parameters:
 *       - in: path
 *         name: user_id
 *         required: true
 *         schema:
 *           type: string
 *         example: U0001
 *     responses:
 *       200:
 *         description: Profile statistics fetched successfully
 */
router.get(
  "/:user_id/stats",
  profileController.getProfileStats
);


module.exports = router;