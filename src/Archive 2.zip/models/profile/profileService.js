const profileRepository = require("./profileRepository");

const getProfile = async (user_id) => {
  const profile =
    await profileRepository.getUserProfile(user_id);

  if (!profile) {
    throw new Error("User not found");
  }

  const stats =
    await profileRepository.getProfileStats(user_id);

  return {
    profile,
    stats,
  };
};

module.exports = {
  getProfile,
};