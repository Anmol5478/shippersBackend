const db = require("../../config/db");

/**
 * Get user profile
 */
const getUserProfile = async (user_id) => {
  const query = `
    SELECT
      user_id,
      full_name,
      email,
      phone,
      gender
    FROM users
    WHERE user_id = ?
    LIMIT 1
  `;

  const [rows] = await db.query(query, [user_id]);

  return rows[0] || null;
};


/**
 * Get profile statistics
 */
const getProfileStats = async (user_id) => {
  const ridesQuery = `
    SELECT COUNT(*) AS published_journeys
    FROM rides
    WHERE user_id = ?
  `;

  const [rideRows] = await db.query(
    ridesQuery,
    [user_id]
  );

  return {
    active_parcels: 0,
    published_journeys:
      rideRows[0]?.published_journeys || 0,
    wallet_balance: 0,
    total_earnings: 0,
  };
};


module.exports = {
  getUserProfile,
  getProfileStats,
};